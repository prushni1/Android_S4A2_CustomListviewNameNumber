package com.connect.s4a2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.connect.s4a2.adapters.StudentAdapter;
import com.connect.s4a2.model.Student;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    String name1,name2,name3,name4,name5,name6,name7,
            phone1,phone2,phone3,phone4,phone5,phone6,phone7;

     ArrayList<Student> mArrayList;
     StudentAdapter mStudentAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv= (ListView) findViewById(R.id.listview);

        mArrayList=new ArrayList<>();

        mArrayList.add(new Student("a",123));
        mArrayList.add(new Student("b",123));
        mArrayList.add(new Student("c",123));
        mArrayList.add(new Student("d",123));
        mArrayList.add(new Student("e",123));
        mArrayList.add(new Student("f",123));
        mArrayList.add(new Student("g",123));

        mStudentAdapter = new StudentAdapter(this,mArrayList);
        lv.setAdapter(mStudentAdapter);



    }
}
