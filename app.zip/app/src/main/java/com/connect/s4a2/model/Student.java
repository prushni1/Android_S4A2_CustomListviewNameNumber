package com.connect.s4a2.model;

/**
 * Created by win7 on 28-09-2016.
 */

public class Student {
    String name;
    int phone;

    public Student() {
    }

    public Student(String name, int phone) {
        this.name = name;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }


}
